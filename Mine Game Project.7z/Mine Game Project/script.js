class MinesGame {
    constructor() {
        this.gridSize = 25; 
        this.mines = [];
        this.revealedCells = new Set();
        this.gameActive = false;
        this.balance = 0; 
        this.currentBet = 0;
        this.selectedMultiplier = 2;
        this.currentMultiplier = 1; 
        this.betSet = false;
        this.gameHistory = [];
        this.multiplierTable = this.createMultiplierTable();
        this.currentOTP = null;
        this.pendingBalance = 0;
        this.userEmail = '';
        this.initializeEmailJS();
        this.initializeElements();
        this.setupEventListeners();
    }

    initializeEmailJS() {
        
        emailjs.init("ToriJv6a4177MZcS-"); 
    }

    generateOTP() {
        return Math.floor(100000 + Math.random() * 900000).toString();
    }

    async sendOTPEmail(email, otp, amount) {
        const templateParams = {
            to_email: email,
            otp_code: otp,
            amount: amount,
            game_name: "Phycxs's Mining Game"
        };

        try {
            console.log('Sending email with params:', templateParams);
            console.log('Using Service ID: service_9oxxrmg');
            console.log('Using Template ID: template_qp1q958');
            console.log('Using Public Key: ToriJv6a4177MZcS-');
            
            
            const result = await emailjs.send(
                "service_9oxxrmg",
                "template_qp1q958",
                templateParams,
                "ToriJv6a4177MZcS-" 
            );
            
            console.log('Email sent successfully!', result);
            return true;
        } catch (error) {
            console.error('Method 1 failed, trying alternative method...');
            console.error('Error status:', error.status);
            console.error('Error text:', error.text);
            
                         
             try {
                 const result2 = await emailjs.send(
                     "service_9oxxrmg",
                     "template_qp1q958",
                     {
                         user_email: email,
                         to_email: email,
                         otp_code: otp,
                         amount: amount,
                         game_name: "Phycxs's Mining Game",
                         to_name: "User"
                     }
                 );
                console.log('Method 2 successful!', result2);
                return true;
            } catch (error2) {
                console.error('Both methods failed:', error2);
                return false;
            }
        }
    }

    createMultiplierTable() {
        
        return {
            1: { // 1 mine
                1: 1.04, 2: 1.09, 3: 1.14, 4: 1.19, 5: 1.25,
                6: 1.32, 7: 1.39, 8: 1.47, 9: 1.56, 10: 1.67,
                11: 1.78, 12: 1.91, 13: 2.06, 14: 2.22, 15: 2.41,
                16: 2.63, 17: 2.88, 18: 3.17, 19: 3.52, 20: 3.94,
                21: 4.44, 22: 5.08, 23: 5.91, 24: 7.00
            },
            2: { // 2 mines
                1: 1.08, 2: 1.17, 3: 1.27, 4: 1.39, 5: 1.52,
                6: 1.67, 7: 1.84, 8: 2.04, 9: 2.27, 10: 2.54,
                11: 2.85, 12: 3.22, 13: 3.66, 14: 4.19, 15: 4.84,
                16: 5.65, 17: 6.67, 18: 7.98, 19: 9.72, 20: 12.08,
                21: 15.36, 22: 20.25, 23: 27.60
            },
            3: { // 3 mines
                1: 1.14, 2: 1.32, 3: 1.54, 4: 1.83, 5: 2.20,
                6: 2.67, 7: 3.29, 8: 4.11, 9: 5.20, 10: 6.67,
                11: 8.71, 12: 11.61, 13: 15.89, 14: 22.39, 15: 32.40,
                16: 48.60, 17: 75.79, 18: 124.20, 19: 217.80, 20: 435.60,
                21: 1089.00, 22: 3267.00
            },
            4: { // 4 mines
                1: 1.22, 2: 1.52, 3: 1.94, 4: 2.53, 5: 3.38,
                6: 4.63, 7: 6.53, 8: 9.52, 9: 14.29, 10: 22.22,
                11: 36.30, 12: 62.22, 13: 113.85, 14: 227.70, 15: 500.50,
                16: 1251.25, 17: 3571.00, 18: 11904.00, 19: 51336.00, 20: 308016.00,
                21: 2772144.00
            },
            5: { // 5 mines
                1: 1.32, 2: 1.78, 3: 2.50, 4: 3.63, 5: 5.50,
                6: 8.80, 7: 14.67, 8: 25.67, 9: 47.67, 10: 95.33,
                11: 200.67, 12: 458.86, 13: 1146.50, 14: 3181.83, 15: 10000.00,
                16: 36667.00, 17: 157143.00, 18: 942857.00, 19: 8228571.00, 20: 131657143.00
            },
            6: { // 6 mines
                1: 1.44, 2: 2.14, 3: 3.29, 4: 5.29, 5: 9.00,
                6: 16.43, 7: 31.64, 8: 64.86, 9: 142.71, 10: 333.33,
                11: 833.33, 12: 2272.73, 13: 6818.18, 14: 23333.33, 15: 93333.33,
                16: 466667.00, 17: 2916667.00, 18: 23333333.00, 19: 280000000.00
            },
            7: { // 7 mines
                1: 1.58, 2: 2.61, 3: 4.50, 4: 8.18, 5: 15.75,
                6: 32.14, 7: 70.00, 8: 163.33, 9: 408.33, 10: 1100.00,
                11: 3208.33, 12: 10111.11, 13: 35388.89, 14: 141555.56, 15: 708333.33,
                16: 4541666.67, 17: 38958333.33, 18: 467500000.00
            },
            8: { // 8 mines
                1: 1.75, 2: 3.25, 3: 6.30, 4: 12.86, 5: 27.86,
                6: 64.29, 7: 160.71, 8: 428.57, 9: 1238.10, 10: 3857.14,
                11: 12857.14, 12: 46428.57, 13: 185714.29, 14: 857142.86, 15: 4857142.86,
                16: 34285714.29, 17: 343857142.86
            },
            9: { // 9 mines
                1: 1.96, 2: 4.13, 3: 8.86, 4: 20.57, 5: 51.43,
                6: 137.14, 7: 392.73, 8: 1200.00, 9: 3954.55, 10: 14181.82,
                11: 54545.45, 12: 227272.73, 13: 1060606.06, 14: 5666666.67, 15: 37777777.78,
                16: 340909090.91
            },
            10: { // 10 mines
                1: 1.67, 2: 3.33, 3: 10.00, 4: 25.00, 5: 66.67,
                6: 200.00, 7: 666.67, 8: 2400.00, 9: 9333.33, 10: 40000.00,
                11: 186666.67, 12: 960000.00, 13: 5600000.00, 14: 37333333.33, 15: 336000000.00
            }
        };
    }

    initializeElements() {
        this.grid = document.getElementById('game-grid');
        this.balanceDisplay = document.getElementById('balance');
        this.betInput = document.getElementById('bet-amount');
        this.betMinusButton = document.getElementById('bet-minus');
        this.betPlusButton = document.getElementById('bet-plus');
        this.resetBetButton = document.getElementById('reset-bet');
        this.setBetButton = document.getElementById('set-bet');
        this.startButton = document.getElementById('start-game');
        this.cashoutButton = document.getElementById('cashout');
        this.messageDisplay = document.getElementById('game-message');
        this.multiplierSelect = document.getElementById('multiplier-select');
        this.potentialWinningsDisplay = document.getElementById('potential-winnings');
        this.historyList = document.getElementById('history-list');
        this.betSection = document.getElementById('bet-section');
        this.playingSection = document.getElementById('playing-section');
        

        this.addBalanceBtn = document.getElementById('add-balance');
        this.balanceModal = document.getElementById('balance-modal');
        this.closeModal = document.getElementById('close-modal');
        this.userEmailInput = document.getElementById('user-email');
        this.balanceAmountInput = document.getElementById('balance-amount');
        this.sendOTPBtn = document.getElementById('send-otp');
        this.otpInput = document.getElementById('otp-input');
        this.verifyOTPBtn = document.getElementById('verify-otp');
        this.resendOTPBtn = document.getElementById('resend-otp');
        this.closeSuccessBtn = document.getElementById('close-success');
        this.emailDisplay = document.getElementById('email-display');
        this.addedAmountDisplay = document.getElementById('added-amount');
        
     
        this.step1 = document.getElementById('step1');
        this.step2 = document.getElementById('step2');
        this.step3 = document.getElementById('step3');
    }

    setupEventListeners() {
        this.betMinusButton.addEventListener('click', () => this.adjustBet(-1));
        this.betPlusButton.addEventListener('click', () => this.adjustBet(1));
        this.resetBetButton.addEventListener('click', () => this.resetBet());
        this.setBetButton.addEventListener('click', () => this.setBet());
        this.startButton.addEventListener('click', () => this.startGame());
        this.cashoutButton.addEventListener('click', () => this.handleCashout());
        this.multiplierSelect.addEventListener('change', (e) => {
            this.selectedMultiplier = parseInt(e.target.value);
            this.betSet = false;
            this.startButton.disabled = true;
        });

       
        this.betInput.addEventListener('input', () => this.handleBetInput());
        this.betInput.addEventListener('blur', () => this.validateBetInput());
        this.betInput.addEventListener('keypress', (e) => this.handleBetKeypress(e));

        
        this.addBalanceBtn.addEventListener('click', () => this.openBalanceModal());
        this.closeModal.addEventListener('click', () => this.closeBalanceModal());
        this.sendOTPBtn.addEventListener('click', () => this.handleSendOTP());
        this.verifyOTPBtn.addEventListener('click', () => this.handleVerifyOTP());
        this.resendOTPBtn.addEventListener('click', () => this.handleResendOTP());
        this.closeSuccessBtn.addEventListener('click', () => this.closeBalanceModal());

        
        this.balanceModal.addEventListener('click', (e) => {
            if (e.target === this.balanceModal) {
                this.closeBalanceModal();
            }
        });
    }

    openBalanceModal() {
        this.balanceModal.style.display = 'block';
        this.resetModalSteps();
    }

    closeBalanceModal() {
        this.balanceModal.style.display = 'none';
        this.resetModalSteps();
        this.clearModalInputs();
    }

    resetModalSteps() {
        this.step1.style.display = 'block';
        this.step2.style.display = 'none';
        this.step3.style.display = 'none';
    }

    clearModalInputs() {
        this.userEmailInput.value = '';
        this.balanceAmountInput.value = '';
        this.otpInput.value = '';
        this.currentOTP = null;
        this.pendingBalance = 0;
        this.userEmail = '';
    }

    async handleSendOTP() {
        const email = this.userEmailInput.value.trim();
        const amount = parseFloat(this.balanceAmountInput.value);

        if (!email || !email.includes('@')) {
            alert('Please enter a valid email address');
            return;
        }

        if (!amount || amount <= 0) {
            alert('Please enter a valid amount');
            return;
        }

        this.userEmail = email;
        this.pendingBalance = amount;
        this.currentOTP = this.generateOTP();

        this.sendOTPBtn.textContent = 'Sending...';
        this.sendOTPBtn.disabled = true;

        const emailSent = await this.sendOTPEmail(email, this.currentOTP, amount);
        if (!emailSent) {
            alert('Failed to send OTP. Please try again.');
            this.sendOTPBtn.textContent = 'Send OTP';
            this.sendOTPBtn.disabled = false;
            return;
        }
        
        
        console.log('OTP sent to email:', this.currentOTP);

        
        this.emailDisplay.textContent = email;
        this.step1.style.display = 'none';
        this.step2.style.display = 'block';
        
        this.sendOTPBtn.textContent = 'Send OTP';
        this.sendOTPBtn.disabled = false;
    }

    async handleResendOTP() {
        if (!this.userEmail || !this.pendingBalance) return;

        this.currentOTP = this.generateOTP();
        this.resendOTPBtn.textContent = 'Sending...';
        this.resendOTPBtn.disabled = true;

        console.log('New OTP for testing:', this.currentOTP);
        
       
        await this.sendOTPEmail(this.userEmail, this.currentOTP, this.pendingBalance);
        
        setTimeout(() => {
            this.resendOTPBtn.textContent = 'Resend OTP';
            this.resendOTPBtn.disabled = false;
        }, 2000);
    }

    handleVerifyOTP() {
        const enteredOTP = this.otpInput.value.trim();

        if (!enteredOTP) {
            alert('Please enter the OTP');
            return;
        }

        if (enteredOTP === this.currentOTP) {
            
            this.balance += this.pendingBalance;
            this.updateBalance();
            
            this.addedAmountDisplay.textContent = this.pendingBalance.toFixed(2);
            this.step2.style.display = 'none';
            this.step3.style.display = 'block';
            
            this.showMessage(`Successfully added $${this.pendingBalance.toFixed(2)} to your balance!`);
        } else {
            alert('Invalid OTP. Please try again.');
            this.otpInput.value = '';
        }
    }

    adjustBet(amount) {
        this.currentBet = Math.max(0, Math.min(this.balance, this.currentBet + amount));
        this.betInput.value = this.currentBet;
        this.betSet = false;
        this.startButton.disabled = true;
    }

    resetBet() {
        this.currentBet = 0;
        this.betInput.value = this.currentBet;
        this.betSet = false;
        this.startButton.disabled = true;
        this.showMessage('Bet reset to $0');
    }

    setBet() {
        if (this.currentBet <= 0) {
            this.showMessage('Please set a bet amount greater than $0!');
            return;
        }

        if (this.currentBet > this.balance) {
            this.showMessage('Insufficient balance!');
            return;
        }

        this.betSet = true;
        this.startButton.disabled = false;
        this.setBetButton.disabled = true;
        this.showMessage(`Bet set: $${this.currentBet} with ${this.selectedMultiplier} mines`);
    }

    startGame() {
        if (!this.betSet) {
            this.showMessage('Please set your bet first!');
            return;
        }

        
        this.gameActive = true;
        this.revealedCells.clear();
        this.currentMultiplier = 1; 
        this.generateGrid();
        this.placeMines();
        this.startButton.disabled = true;
        this.setBetButton.disabled = false;
        this.cashoutButton.disabled = false;
        this.updatePotentialWinnings(); 
        this.showPlayingState();
        this.showMessage(`Game started! ${this.selectedMultiplier} mines on the field.`);
    }

    showPlayingState() {
        this.betSection.style.display = 'none';
        this.playingSection.style.display = 'flex';
    }

    showBettingState() {
        this.betSection.style.display = 'flex';
        this.playingSection.style.display = 'none';
        this.betSet = false;
        this.startButton.disabled = true;
        this.setBetButton.disabled = false;
    }

    generateGrid() {
        this.grid.innerHTML = '';
        for (let i = 0; i < this.gridSize; i++) {
            const cell = document.createElement('div');
            cell.className = 'grid-cell';
            cell.dataset.index = i;
            cell.addEventListener('click', () => this.handleCellClick(i));
            this.grid.appendChild(cell);
        }
    }

    placeMines() {
        this.mines = [];
        const numMines = this.selectedMultiplier;

        while (this.mines.length < numMines) {
            const mineIndex = Math.floor(Math.random() * this.gridSize);
            if (!this.mines.includes(mineIndex)) {
                this.mines.push(mineIndex);
            }
        }
    }

    handleCellClick(index) {
        if (!this.gameActive || this.revealedCells.has(index)) return;

        const cell = this.grid.children[index];
        this.revealedCells.add(index);

        if (this.mines.includes(index)) {
            this.handleMineReveal(index);
        } else {
            this.handleGemReveal(index);
        }
    }

    handleMineReveal(index) {
        const cell = this.grid.children[index];
        cell.classList.add('mine', 'revealed');
        cell.textContent = '💣';
        this.gameActive = false;
        
        
        this.balance -= this.currentBet;
        this.updateBalance();
        
        this.revealAllMines();
        this.startButton.disabled = false;
        this.cashoutButton.disabled = true;
        this.updatePotentialWinnings();
        this.addToHistory('loss', 0, this.revealedCells.size - 1);
        this.showBettingState();
        this.showMessage('Game Over! You hit a mine.');
    }

    handleGemReveal(index) {
        const cell = this.grid.children[index];
        cell.classList.add('gem', 'revealed');
        cell.textContent = '💎';
        
        
        const gemsRevealed = this.revealedCells.size;
        const numMines = this.selectedMultiplier;
        
        if (this.multiplierTable[numMines] && this.multiplierTable[numMines][gemsRevealed]) {
            this.currentMultiplier = this.multiplierTable[numMines][gemsRevealed];
        }
        
        this.updatePotentialWinnings();
        
        
        if (this.revealedCells.size === this.gridSize - this.mines.length) {
            this.handleWin();
        }
    }

    handleCashout() {
        if (!this.gameActive) return;
        
        const winnings = this.calculateCurrentWinnings();
        
        this.balance = this.balance - this.currentBet + winnings;
        this.updateBalance();
        this.gameActive = false;
        this.startButton.disabled = false;
        this.cashoutButton.disabled = true;
        this.updatePotentialWinnings();
        this.addToHistory('cashout', winnings, this.revealedCells.size);
        this.showBettingState();
        this.showMessage(`Cashed out! You won $${winnings.toFixed(2)}!`);
    }

    calculateCurrentWinnings() {
        return Math.floor(this.currentBet * this.currentMultiplier * 100) / 100;
    }

    updatePotentialWinnings() {
        if (!this.gameActive) {
            this.potentialWinningsDisplay.textContent = '0';
            return;
        }
        const winnings = this.calculateCurrentWinnings();
        this.potentialWinningsDisplay.textContent = winnings.toFixed(2);
    }

    handleWin() {
        const winnings = this.calculateCurrentWinnings();
        
        this.balance = this.balance - this.currentBet + winnings;
        this.updateBalance();
        this.gameActive = false;
        this.startButton.disabled = false;
        this.cashoutButton.disabled = true;
        this.updatePotentialWinnings();
        this.addToHistory('win', winnings, this.revealedCells.size);
        this.showBettingState();
        this.showMessage(`You won $${winnings.toFixed(2)}!`);
    }

    addToHistory(type, winnings, gemsRevealed) {
        const historyItem = {
            type: type,
            bet: this.currentBet,
            multiplier: this.selectedMultiplier,
            gemsRevealed: gemsRevealed,
            winnings: winnings,
            timestamp: new Date()
        };

        this.gameHistory.unshift(historyItem);
        this.updateHistoryDisplay();
    }

    updateHistoryDisplay() {
        const noHistory = this.historyList.querySelector('.no-history');
        if (noHistory) {
            noHistory.remove();
        }

        
        const existingItems = this.historyList.querySelectorAll('.history-item');
        existingItems.forEach(item => item.remove());

        this.gameHistory.forEach(item => {
            const historyElement = document.createElement('div');
            historyElement.className = `history-item ${item.type}`;
            
            let resultText = '';
            let profitLoss = '';
            
            if (item.type === 'win') {
                resultText = 'WIN';
                profitLoss = `+$${item.winnings.toFixed(2)}`;
            } else if (item.type === 'loss') {
                resultText = 'LOSS';
                profitLoss = `-$${item.bet}`;
            } else if (item.type === 'cashout') {
                resultText = 'CASHOUT';
                profitLoss = `+$${item.winnings.toFixed(2)}`;
            }

            historyElement.innerHTML = `
                <div class="history-item-header">
                    <span class="history-result ${item.type}">${resultText}</span>
                    <span class="history-result ${item.type}">${profitLoss}</span>
                </div>
                <div class="history-details">
                    Bet: $${item.bet} | ${item.multiplier} mines | ${item.gemsRevealed} gems
                </div>
            `;

            this.historyList.appendChild(historyElement);
        });
    }

    revealAllMines() {
        this.mines.forEach(index => {
            const cell = this.grid.children[index];
            if (!cell.classList.contains('revealed')) {
                cell.classList.add('mine', 'revealed');
                cell.textContent = '💣';
            }
        });
    }

    updateBalance() {
        this.balanceDisplay.textContent = this.balance.toFixed(3).replace(/\.?0+$/, '');
    }

    showMessage(message) {
        this.messageDisplay.textContent = message;
    }

    handleBetInput() {
        
        this.betSet = false;
        this.startButton.disabled = true;
        
        
        let value = this.betInput.value.replace(/[^0-9.]/g, '');
        
       
        const parts = value.split('.');
        if (parts.length > 2) {
            value = parts[0] + '.' + parts.slice(1).join('');
        }
        
       
        if (parts[1] && parts[1].length > 2) {
            value = parts[0] + '.' + parts[1].substring(0, 2);
        }
        
        this.betInput.value = value;
    }

    validateBetInput() {
        let value = parseFloat(this.betInput.value) || 0;
        
       
        value = Math.max(0, Math.min(this.balance, value));
        
       
        this.currentBet = value;
        this.betInput.value = value;
        
        
        this.betSet = false;
        this.startButton.disabled = true;
    }

    handleBetKeypress(e) {
        
        if ([8, 9, 27, 13, 46, 110, 190].indexOf(e.keyCode) !== -1 ||
            
            (e.keyCode === 65 && e.ctrlKey === true) ||
            (e.keyCode === 67 && e.ctrlKey === true) ||
            (e.keyCode === 86 && e.ctrlKey === true) ||
            (e.keyCode === 88 && e.ctrlKey === true) ||
            (e.keyCode === 90 && e.ctrlKey === true) ||
            
            (e.keyCode >= 35 && e.keyCode <= 40)) {
            return;
        }
       
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    }
}


window.addEventListener('load', () => {
    new MinesGame();
}); 